package Game.ModelLayer.MovementStrategy;

import Game.ModelLayer.Snake;

public interface MovementStrategy {
    void movimentoSnake(Snake snake);
}
