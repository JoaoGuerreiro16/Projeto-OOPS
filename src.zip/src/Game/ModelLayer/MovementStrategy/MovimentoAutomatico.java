package Game.ModelLayer.MovementStrategy;
import Game.ModelLayer.Snake;

public class MovimentoAutomatico implements MovementStrategy {

    @Override
    public void movimentoSnake(Snake snake) {
        
    }
}
