package Game.ViewLayer;

public class GraphicUI implements UI {

    public void display(RasterizadordeJogo rasterizer)
    {
       
    }
    
}
